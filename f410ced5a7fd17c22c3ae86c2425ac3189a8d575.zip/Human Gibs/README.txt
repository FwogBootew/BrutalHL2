this wasn't supposed to be uploaded on garrysmod.org, 
becouse this was just a simple idea for the people of the Black Mesa Source team (god bless these people for making such an awesome mod), but here you go.
oh before i forget, the title is Human gibs, but there are som alien gibs in here too.

and for the Garry's Mod players:
installation:
just put the materials and the models folders in your garrysmod/garrysmod folder.

you can find these models in your browse tab, go to garrysmod and there should be a folder called gibs.
op the folder and click with your right mouse button on one of the models and click on "add to spawnlist/menu" and choose "all of these icons",
and add them to your useful comic props list or make a new list.